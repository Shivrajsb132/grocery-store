from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from database import init_db

app = Flask(__name__)
init_db()

def get_db_connection():
    conn = sqlite3.connect('grocery.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    conn = get_db_connection()
    items = conn.execute('SELECT * FROM items').fetchall()
    reorder_items = conn.execute('SELECT * FROM items WHERE quantity < reorder_level').fetchall()
    conn.close()
    return render_template('index.html', items=items, reorder_items=reorder_items)

@app.route('/add', methods=['GET', 'POST'])
def add_item():
    if request.method == 'POST':
        name = request.form['name']
        quantity = int(request.form['quantity'])
        price = float(request.form['price'])
        supplier = request.form['supplier']
        reorder_level = int(request.form['reorder_level'])

        conn = get_db_connection()
        conn.execute('INSERT INTO items (name, quantity, price, supplier, reorder_level) VALUES (?, ?, ?, ?, ?)',
                     (name, quantity, price, supplier, reorder_level))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('add_item.html')

@app.route('/delete/<int:id>')
def delete_item(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM items WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
